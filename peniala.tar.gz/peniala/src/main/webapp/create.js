/**
 * 
 */

const add = document.querySelector("#add");
const remove = document.querySelector("#remove");
	
let index = 1;
	
add.addEventListener("click",(event) => {
	console.log("mety");
	const div = document.createElement("div");            
	        /* let name = "state"+index;
	        div.setAttribute("name",name); */
	div.className = "s"+index;
	div.innerHTML = `
						<input type="text" name="${"sname"+index}" placeholder="State" required>
						<select name="${"priority"+index}">
							<option value="1">Important - Exigent</option>
							<option value="2">Important - Less exigent</option>
							<option value="3">Less important - Exigent</option>
						</select>
						<input type="text" name="${"descri"+index}" placeholder="Description ...">
	              `;
	 document.querySelector(".step").append(div);
	 index++;
});

remove.addEventListener("click",(event) => {
      if(index > 1) index--;
      document.querySelector(".step").lastChild.remove();
});