
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.NullPointerException;

/**
 * Servlet implementation class CreateProject
 */
public class CreateProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateProject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
			Project p = new Project();
			
			p.setName(request.getParameter("name"));
			p.setTarget(request.getParameter("target"));
			p.setDeadline(request.getParameter("deadline"));
			
			int c = 0;
			for(int i=1; request.getParameter("sname"+i) instanceof String; i++) {
				c++;
			}
			
			Step[] s = new Step[c];
			
			for(int i=1; request.getParameter("sname"+i) instanceof String; i++) {
				s[i-1] = new Step();
				s[i-1].setSname(request.getParameter("sname"+i));
				s[i-1].setLevel(Integer.parseInt(request.getParameter("priority"+i)));
				s[i-1].setDescription(request.getParameter("descri"+i));
			}
			
			p.setSteps(s);
			
			p.addProject(p);
		}
		catch(NullPointerException e) {
			//response.getWriter().append("Served at: ").append(request.getContextPath());
			e.printStackTrace();
		}
		
		request.getRequestDispatcher("create.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
