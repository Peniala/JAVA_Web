

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class ProjectView
 */
public class ProjectView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProjectView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		int i = new Project().listProject().length;
		
		Project[] p1 = new Project[i];
		String[] pname = new String[i];		
		String[] ptarget = new String[i];		
		String[] pdeadline = new String[i];		
		String[][] psname = new String[i][];		
		int[][] pspriority = new int[i][];		
		String[][] psdescri = new String[i][];		

		for(int k=0; k < i; k++) {
			pname[k] = p1[k].getName();
			ptarget[k] = p1[k].getTarget();
			pdeadline[k] = p1[k].getDeadline();
			
			int j = p1[k].getSteps().length;
			
			psname[k] = new String[j];
			pspriority[k] = new int[j];
			psdescri[k] = new String[j];
			
			for(int l=0; l < j; l++) {
				
				psname[k][l] = p1[k].getSteps()[l].getSname();
				pspriority[k][l] = p1[k].getSteps()[l].getLevel();
				psdescri[k][l] = p1[k].getSteps()[l].getDescription();
				l++;
			}
			
		}
		
		
		request.setAttribute("pname", pname);
		request.setAttribute("ptarget", ptarget);
		request.setAttribute("pdeadline", pdeadline);
		request.setAttribute("psname", psname);
		request.setAttribute("pspriority", pspriority);
		request.setAttribute("psdescri", psdescri);
		
		request.getRequestDispatcher("projectView.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
