import java.sql.*;

public class Step {
	private String sname;
	private String description;
	private int priority;
	
	public Step() {
		
	}
	public void setSname(String s) {
		this.sname = s;
	}
	public void setDescription(String s) {
		this.description = s;
	}
	public void setLevel(int l) {
		this.priority = l;
	}
	public String getSname() {
		return this.sname;
	}
	public String getDescription() {
		return this.description;
	}
	public int getLevel() {
		return this.priority;
	}
	public void addStep(Step s, int id_project) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
				
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIT", "mit", "123456");
			
			String requete = "INSERT INTO  (sname,priority,id_project) VALUES (?, ?,?)";
	        PreparedStatement preparedStatement = connection.prepareStatement(requete);

	        preparedStatement.setString(1,s.getSname());
	        preparedStatement.setInt(2, s.getLevel());
	        preparedStatement.setInt(3, id_project);

	        preparedStatement.executeUpdate();

	        preparedStatement.close();
	        connection.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public Step[] listSteps(int id) {
		int c=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIT", "mit", "123456");
			
			PreparedStatement ps = connection.prepareStatement("SELECT COUNT(*) FROM Project where id_project=?");
            ResultSet rs = ps.executeQuery();
            ps.setInt(1, id);
            
            if(rs.next()) c = rs.getInt("COUNT(*)");

	        ps.executeUpdate();
	        
	        rs.close();
	        ps.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		Step[] s = new Step[c];
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIT", "mit", "123456");
			
			PreparedStatement ps = connection.prepareStatement("SELECT sname,priority,decri FROM Project");
            ResultSet rs = ps.executeQuery();
            
            int i=0;
            
            while(rs.next()) { 
            	s[i] = new Step();
            	s[i].setSname(rs.getString("sname"));
            	s[i].setLevel(priority = rs.getInt("priority"));
            	s[i].setDescription(description = rs.getString("descri"));
            	
            	i++;
            }

	        ps.executeUpdate();
	        
	        rs.close();
	        ps.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return s;
	}
}
