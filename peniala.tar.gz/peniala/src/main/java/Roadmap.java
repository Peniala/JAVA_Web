
public class Roadmap {
	private Project project;
	private float progression;
	
	public Roadmap() {
		
	}
	public void setProject(Project p) {
		this.project = p;
	}
	public void setProgress(float pr) {
		this.progression = pr;
	}
	public Project getProject() {
		return this.project;
	}
	public float getProgress() {
		return this.progression;
	}
}
