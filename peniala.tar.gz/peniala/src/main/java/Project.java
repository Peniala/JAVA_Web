import java.sql.*;

public class Project {
	private String name;
	private String target;
	private String deadline;
	private Step[] steps;
	
	public Project() {
		
	}
	public void setName(String s) {
		this.name = s;
	}
	public void setTarget(String s) {
		this.target = s;
	}
	public void setSteps(Step[] s) {
		this.steps = s;
	}
	public void setDeadline(String s) {
		this.deadline = s;
	}
	public String getName() {
		return this.name;
	}
	public String getTarget() {
		return this.target;
	}
	public Step[] getSteps() {
		return this.steps;
	}
	public String getDeadline() {
		return this.deadline;
	}
	public void addProject(Project p) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
				
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIT", "mit", "123456");
			
			String request = "INSERT INTO Project (name, target, deadline) VALUES (?, ?)";
	        PreparedStatement preparedStatement = connection.prepareStatement(request);

	        preparedStatement.setString(1, p.getName());
	        preparedStatement.setString(2, p.getTarget());
	        preparedStatement.setString(3, p.getDeadline());

	        preparedStatement.executeUpdate();

	        preparedStatement.close();
	        
	        
            PreparedStatement ps = connection.prepareStatement("SELECT id_project FROM Project where name=?");
            ResultSet rs = ps.executeQuery();
            ps.setString(1, p.getName());
            
            int id = rs.getInt("id_project");
            
            rs.close();
            ps.close();
            connection.close();
            
            for(int i=0; i < p.getSteps().length ; i++) {
            	p.steps[i].addStep(p.steps[i],id);
            }
            
		}
		catch(SQLException e) {
			System.out.println("sql");
			e.printStackTrace();
		}
		catch(Exception ex) {
			System.out.println("class");
			ex.printStackTrace();
		}
	}
	public Project[] listProject() {
		int c = 0;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIT", "mit", "123456");
			
			PreparedStatement ps = connection.prepareStatement("SELECT COUNT(*) FROM Project");
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()) c = rs.getInt("COUNT(*)");

	        ps.executeUpdate();
	        
	        rs.close();
	        ps.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		Project[] p = new Project[c];
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/MIT", "mit", "123456");
			
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM Project");
            ResultSet rs = ps.executeQuery();
            
            int i=0;
            
            while(rs.next()) {
            	p[i] = new Project();
            	p[i].setSteps(p[i].steps[i].listSteps(rs.getInt("id_project")));
            	p[i].setName(rs.getString("name"));
            	p[i].setTarget(rs.getString("target"));
            	p[i].setDeadline(rs.getString("deadline"));
            	
            	i++;
            }

	        ps.executeUpdate();
	        
	        rs.close();
	        ps.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return p;
	}
}
